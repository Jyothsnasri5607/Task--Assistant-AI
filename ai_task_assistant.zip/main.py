print("AI Task Assistant")
