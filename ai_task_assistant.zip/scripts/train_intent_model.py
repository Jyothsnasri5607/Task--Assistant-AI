print("train")
