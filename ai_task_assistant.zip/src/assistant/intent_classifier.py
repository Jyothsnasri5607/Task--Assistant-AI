class IntentClassifier:
    def classify(self, text):
        return "add_task"
