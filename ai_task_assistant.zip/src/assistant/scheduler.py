class Scheduler:
    def schedule(self, task): pass
