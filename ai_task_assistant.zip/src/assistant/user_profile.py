class UserProfile:
    def update(self, data): pass
