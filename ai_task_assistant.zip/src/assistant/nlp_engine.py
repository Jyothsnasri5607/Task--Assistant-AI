class NLPEngine:
    def process(self, text):
        return {"tokens": text.split()}
