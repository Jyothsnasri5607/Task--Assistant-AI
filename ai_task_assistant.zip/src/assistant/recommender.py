class Recommender:
    def suggest(self): return []
