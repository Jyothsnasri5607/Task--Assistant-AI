class UserDB:
    def save(self, u): pass
