def connect(): return None
