class TaskDB:
    def create(self, t): pass
