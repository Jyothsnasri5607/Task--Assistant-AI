def log(req): pass
