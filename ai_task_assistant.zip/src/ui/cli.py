def run(): print("CLI")
